close all; clc; clear;

model_num = 1;

isVal = true;
%isVal = false;

if(isVal) %val
    skipsize = 0;
    step = 363;
    save_root = '/mnt/lustre/zhaohengshuang/sceneparsing/voc/mc_result/resnet101_55354do012loss_ft1/'
    val_list = 'list/val1452.txt';
    eval_list = 'list/val.txt';
else %test
    skipsize = 0;
    step = 364;
    save_root = '/mnt/lustre/zhaohengshuang/sceneparsing/voc/mc_result/submit/resnet101_55354do012loss_ft2/'
    val_list = 'list/test.txt';
end

model_weights = '/mnt/lustre/zhaohengshuang/sceneparsing/coco/model/resnet101_55354do012loss_ft1/model/train_iter_30000.caffemodel';
model_deploy_prefix = '/mnt/lustre/zhaohengshuang/sceneparsing/voc/matcaffe/resnet101_55354do012loss/';

is_save_feat = false;
save_gray_folder = [save_root 'gray/'];
save_color_folder = [save_root 'color/'];
save_feat_folder = [save_root 'feat/'];

acc = double.empty;
iou = double.empty;
gpu_id_array=[0:3];
runID = 1;
index_array=[(runID-1)*4+1:runID*4];

for i=1:model_num
    parfor j=1:size(gpu_id_array,2)
      %ms_sub(model_weights,model_deploy_prefix,val_list,is_save_feat,save_gray_folder,save_color_folder,save_feat_folder,gpu_id_array(j),j,500);
      ms_sub(model_weights,model_deploy_prefix,val_list,is_save_feat,save_gray_folder,save_color_folder,save_feat_folder,gpu_id_array(j),index_array(j),step,skipsize);
    end
    %[sub_acc,sub_iou] = ms_eval(save_gray_folder,val_list);
    %acc(i) = sub_acc;
    %iou(i) = sub_iou;
    %model_weights
    if(isVal)
	ms_eval(save_gray_folder,eval_list);
    end
end
