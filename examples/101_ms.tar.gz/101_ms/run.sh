srun --partition=m40part --gres=gpu:4 -n1 --ntasks-per-node=4 matlab -r "ms_all;exit" 2>&1 | tee matlab.log
