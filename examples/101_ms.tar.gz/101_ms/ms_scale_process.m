function data_output = ms_scale_process(net,img_scale,fea_cha,max_size,ori_rows,ori_cols)
    data_output = zeros(ori_rows,ori_cols,fea_cha,'single');
    new_rows = size(img_scale,1);
    new_cols = size(img_scale,2);
    long_size = new_rows;
    short_size = new_cols;
    if(new_cols > long_size)
       long_size = new_cols;
       short_size = new_rows;
    end
    if(long_size <= max_size)
        input_data = preImg(img_scale,max_size);
        score = ms_caffe_process(input_data,net);
        score = score(1:new_rows,1:new_cols,:);
    else
        stride_rate = 2/3;
        stride = ceil(max_size*stride_rate);
        img_pad = img_scale;
        if(short_size<max_size)
           mean_r = 123.68;
           mean_g = 116.779;
           mean_b = 103.939;
           if(new_rows < max_size)
              im_r = padarray(img_pad(:,:,1),[max_size-new_rows,0],mean_r,'post');
              im_g = padarray(img_pad(:,:,2),[max_size-new_rows,0],mean_g,'post');
              im_b = padarray(img_pad(:,:,3),[max_size-new_rows,0],mean_b,'post');
              img_pad = cat(3,im_r,im_g,im_b);
          end
          if(new_cols < max_size)
              im_r = padarray(img_pad(:,:,1),[0,max_size-new_cols],mean_r,'post');
              im_g = padarray(img_pad(:,:,2),[0,max_size-new_cols],mean_g,'post');
              im_b = padarray(img_pad(:,:,3),[0,max_size-new_cols],mean_b,'post');
              img_pad = cat(3,im_r,im_g,im_b);
          end
        end
        pad_rows = size(img_pad,1);
        pad_cols = size(img_pad,2);
        h_grid = ceil(single(pad_rows-max_size)/stride) + 1;
        w_grid = ceil(single(pad_cols-max_size)/stride) + 1;
        data_scale = zeros(pad_rows,pad_cols,fea_cha,'single');
        count_scale = zeros(pad_rows,pad_cols,fea_cha,'single');
        for grid_yidx=1:h_grid
            for grid_xidx=1:w_grid
                s_x = (grid_xidx-1) * stride + 1;
                s_y = (grid_yidx-1) * stride + 1;
                e_x = min(s_x + max_size - 1, pad_cols);
                e_y = min(s_y + max_size - 1, pad_rows);
                s_x = e_x - max_size + 1;
                s_y = e_y - max_size + 1;
                img_sub = img_pad(s_y:e_y,s_x:e_x,:);
                count_scale(s_y:e_y,s_x:e_x,:) = count_scale(s_y:e_y,s_x:e_x,:) + 1;
                input_data = preImg(img_sub,max_size);
                data_scale(s_y:e_y,s_x:e_x,:) = data_scale(s_y:e_y,s_x:e_x,:) + ms_caffe_process(input_data,net);
            end
        end
        score = data_scale./count_scale;
        score = score(1:new_rows,1:new_cols,:); 
    end

    data_output = imresize(score,[ori_rows ori_cols],'bilinear');%1/single(scale);
    data_output = bsxfun(@rdivide, data_output, sum(data_output, 3));
end
