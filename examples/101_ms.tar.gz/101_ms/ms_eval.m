% This script demos evaluation on all the prediction maps in pathPred
% make sure you have corresponding ground truth label maps in pathLab
function [sub_acc,sub_iou] = ms_eval(save_gray_folder,val_list)

%% Options and paths
VERBOSE = 0;    % to show individual image results, set it to 1

% path to image(.jpg), prediction(.png) and annotation(.png)
% *NOTE: change these paths while evaluating your own predictions
root_folder = '/mnt/lustre/zhaohengshuang/dataset/VOC2012';
list = importdata(fullfile(root_folder,val_list));
pathImg = save_gray_folder;
pathPred = save_gray_folder;
pathAnno = '/mnt/lustre/zhaohengshuang/dataset/VOC2012';

addpath(genpath('evaluationCode'));
addpath(genpath('visualizationCode'));

% number of object classes: 150
numClass = 21;
% load class names
load('objectName21.mat');
% load pre-defined colors 
load('colormapvoc.mat');

%% Evaluation
% initialize statistics
cnt=0;
area_intersection = double.empty;
area_union = double.empty;
pixel_accuracy = double.empty;
pixel_correct = double.empty;
pixel_labeled = double.empty;

% main loop
%for i = 1: numel(list)
filesPred = dir(fullfile(pathPred, '*.png'));
for i = 1: numel(filesPred)
    % check file existence
    str = strsplit(list{i});
    strPred = strsplit(str{2},'/');
    strPred = strPred{end};
    filePred = fullfile(pathPred, strPred);
    fileAnno = fullfile(pathAnno, str{2});
    if ~exist(fileAnno, 'file')
        fprintf('Label file [%s] does not exist!\n', fileAnno); continue;
    end

    % read in prediction and label
    imPred = imread(filePred);
    imAnno = imread(fileAnno);
    imPred = imPred + 1;
    imAnno = imAnno + 1;
    imAnno(imAnno==255) = 0;
    imPred = imresize(imPred,[size(imAnno,1), size(imAnno,2)],'nearest');
    
    % check image size
    if size(imPred, 3) ~= 1
        fprintf('Label image [%s] should be a gray-scale image!\n', fileAnno); continue;
    end
    if size(imPred, 1)~=size(imAnno, 1) || size(imPred, 2)~=size(imAnno, 2)
        fprintf('Label image [%s] should have the same size as label image! Resizing...\n', fileLab);
        imPred = imresize(imPred, size(imAnno));
    end

    % compute IoU
    cnt = cnt + 1;
    [area_intersection(:,cnt), area_union(:,cnt)] = intersectionAndUnion(imPred, imAnno, numClass);

    % compute pixel-wise accuracy
    [pixel_accuracy(i), pixel_correct(i), pixel_labeled(i)] = pixelAccuracy(imPred, imAnno);
    fprintf('Evaluating %d/%d... Pixel-wise accuracy: %2.2f%%\n', cnt, numel(filesPred), pixel_accuracy(i)*100.);

    % Verbose: show indivudual image results
    if (VERBOSE)
        % read image
        fileImg = fullfile(pathImg, strrep(filesPred(i).name, '.png', '.jpg'));
        im = imread(fileImg);

        % plot result
        plotResult(im, imPred, imAnno, objectNames, colors, fileImg);
        fprintf('[%s] Pixel-wise accuracy: %2.2f%%\n', fileImg, pixel_accuracy(i)*100.);
        waitforbuttonpress;
    end
end

%% Summary
IoU = sum(area_intersection,2)./sum(eps+area_union,2);
mean_IoU = mean(IoU);
accuracy = sum(pixel_correct)/sum(pixel_labeled);

fprintf('==== Summary IoU ====\n');
for i = 1:numClass
    fprintf('%3d %16s: %.4f\n', i, objectNames{i}, IoU(i));
end
fprintf('Mean IoU over %d classes: %.4f\n', numClass, mean_IoU);
fprintf('Pixel-wise Accuracy: %2.2f%%\n', accuracy*100.);
sub_acc = accuracy*100.;
sub_iou = mean_IoU;
