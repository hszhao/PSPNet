clear all, clc;
addpath('/data2/hszhao/caffe_sg/matlab');

save_gray_folder = '/data2/hszhao/sceneparsing/scripts/mc_ms/test_result/gray/';
save_color_folder = '/data2/hszhao/sceneparsing/scripts/mc_ms/test_result/color/';
root_folder = '/data2/hszhao/ADEChallengeData2016/';
list = importdata(fullfile(root_folder,'validation.txt'));
if(~isdir(save_gray_folder))
    mkdir(save_gray_folder);
end
if(~isdir(save_color_folder))
    mkdir(save_color_folder);
end

mean_r = 123.68;
mean_g = 116.779;
mean_b = 103.939;
fea_cha = 150;
base_size = 640;
addpath(genpath('visualizationCode'));
% load class names
load('objectName150.mat');
% load pre-defined colors 
load('color150.mat');
show_image = false;
scale_array = [1];%[0.5 0.75 1 1.25 1.5 1.75];%[1 1.25 1.5 1.75]
max_size = base_size*scale_array(end)+1;

%model_dir = '/mnt/sceneparsing/scripts/mc_ms/model/';
%net_weights = [model_dir 'train_iter_100000.caffemodel'];
phase = 'test'; % run with phase test (so that dropout isn't applied)
%if ~exist(net_weights, 'file')
%  error('Please download CaffeNet from Model Zoo before you run this demo');
%end
%model_name = ['449.prototxt'];
%net_model = [model_dir model_name];
net_model = '/data2/hszhao/sceneparsing/matcaffe/resnet50/641.prototxt';
net_weights = '/data2/hszhao/sceneparsing/test/resnet50/xjqi/train_iter_30000.caffemodel';
net_weights = '/data2/hszhao/sceneparsing/initmodel/resnet50_100000.caffemodel';
caffe.reset_all();
caffe.set_mode_gpu();
gpu_id = 0;
caffe.set_device(gpu_id);
net = caffe.Net(net_model, net_weights, phase);
    
index = 1;
step = 2000;
for i = (index-1)*step+1:index*step%numel(list)
    fprintf(1, 'processing %d (%d)...\n', i, numel(list));
    str = strsplit(list{i});
    img = imread(fullfile(root_folder,str{1}));
    ori_rows = size(img,1);
    ori_cols = size(img,2);
    data_all = zeros(ori_rows,ori_cols,fea_cha,'single');
    for j = 1:size(scale_array,2)
        long_size = base_size*scale_array(j) + 1;
        new_rows = long_size;
        new_cols = long_size;
        if ori_rows > ori_cols
            new_cols = round(long_size/single(ori_rows)*ori_cols);
        else
            new_rows = round(long_size/single(ori_cols)*ori_rows);
        end
        img_scale = imresize(img,[new_rows new_cols],'bilinear');
        data_all = data_all + ms_scale_process(net,img_scale,fea_cha,max_size,ori_rows,ori_cols);
    end
    
    data_all = data_all/size(scale_array,2);
    data = data_all;%already exp process

    img_fn = strsplit(str{1},'/');
    img_fn = img_fn{end};
    img_fn = img_fn(1:end-4);

    [~,imPred] = max(data,[],3);
    imPred = uint8(imPred);
    rgbPred = colorEncode(imPred, colors);
    imwrite(imPred,[save_gray_folder img_fn, '.png']);
    imwrite(rgbPred,[save_color_folder img_fn, '.png']);
    if show_image
        imAnno_path = str{2};
        imAnno = imread(fullfile(root_folder, 'data_500/', imAnno_path));
        imAnno = imAnno + 1;
        imAnno(imAnno==255) = 0;
        rgbAnno = colorEncode(imAnno, colors);
        % colormaps
        colormap = colorMap(imPred, imAnno, objectNames);
        % plot
        set(gcf, 'Name', [imAnno_path ' [Press any key to the next image...]'],  'NumberTitle','off');

        subplot(231);
        imshow(img); title('Image');
        subplot(232);
        imshow(imPred); title('Prediction-gray');
        subplot(233);
        imshow(imAnno); title('Annotation-gray');
        subplot(234);
        imshow(colormap); title('Colormap');
        subplot(235);
        imshow(rgbPred); title('Prediction-color');
        subplot(236);
        imshow(rgbAnno); title('Annotation-color');
        waitforbuttonpress;
    end
end
caffe.reset_all();
